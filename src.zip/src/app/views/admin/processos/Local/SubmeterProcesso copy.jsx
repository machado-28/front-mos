import { Box, } from "@mui/material";
import { Breadcrumb, SimpleCard } from "app/components";
import React from "react";
import { H3, Paragraph } from "app/components/Typography";
import { useForm } from 'react-hook-form'
import { z } from 'zod'
import { zodResolver } from '@hookform/resolvers/zod'
import { createFilterOptions } from "@mui/material/Autocomplete";
import { Email, Phone, } from "@mui/icons-material";
import {
  CButton,
  CCard,
  CCardBody,
  CCol,

  CForm,

  CFormInput,
  CFormLabel,
  CFormSelect,
  CHeaderDivider,
  CInputGroup,
  CInputGroupText,
  CRow,
} from "@coreui/react";
import { useApi } from "app/hooks/useApi";
import { AppButtonRoot } from "app/components/AppBuutonRoot";
import { useNavigate } from "react-router-dom";
import { functions, values } from "lodash";
import { Bounce, toast } from "react-toastify";
import { listaPais } from "app/utils/paises";
import { Notify, NotifyError } from "app/utils/toastyNotification";
import { useState } from "react";

export default function SubmterProcesso() {

  const addProcessoShema = z.object({
    nome: z.string().min(1, { message: 'Este campo é obrigatorio' }),
    numDocumentoIdentificacao: z.string(),
    contacto: z.object({
      telefone: z.coerce
        .number({ message: 'Telefone Incorrecto' })
        .min(9, { message: 'Este campo é obrigatorio' }),
      email: z.string().min(1, { message: 'Este campo é obrigatorio!' }),

    }),
    enderecoAngola: z.object({
      provincia: z.string().min(5, { message: 'Este campo é obrigatorio' }),
      cidade: z.string().min(5, { message: 'Este campo é obrigatorio' }),

    }),
    nacionalidade: z.string().min(5, { message: 'Este campo é obrigatorio' }),
    estadoCivil: z.coerce.string().min(5, { message: 'Este campo é obrigatorio' }),
    genero: z.string().min(5, { message: 'Este campo é obrigatorio' }),
    codigoPostal: z.string().min(5, { message: 'Este campo é obrigatorio' }),
    dataNascimento: z.coerce.date(),

    enderecoOrigem: z.object({
      provincia: z.string().min(5, { message: 'Este campo é obrigatorio' }),
      cidade: z.string().min(5, { message: 'Este campo é obrigatorio' }),

    }),
    paisNascimento: z.string().min(2, { message: 'Este campo é obrigatorio' }),

  })

  const {
    register,
    reset,
    watch,
    handleSubmit,
    formState: { errors },
  } = useForm({
    resolver: zodResolver(addProcessoShema), shouldFocusError: true,
    progressive: true,
  });


  if (errors) console.log("ERRO", errors);
  const api = useApi();
  const [processo, setProcesso] = useState({});
  const [tipoDocumento, setTipoDocumento] = useState({});
  const [anexos, setAnexos] = useState([]);
  const [erroFile, setErroFile] = useState("");
  const redirectTo = useNavigate();
  const [documentos, setDocumentos] = useState([{ nome: "Bilhete de identidade" }, { nome: "Passa Porte" }, { nome: "Curriculumn Profissional" }])

  const handleFileChange = (event, index) => {
    const fileSize = event.target.files[0].size; // Tamanho do arquivo em bytes
    const maxSize = 2 * 1024 * 1024;
    console.log("SIZE", fileSize, maxSize);
    if (fileSize < maxSize) {
      setErroFile("O tamanho deve ser menor que", maxSize);
      console.log("SIZE", fileSize);
      return
    }
    setAnexos((prev) => [...prev, event.target.files[0]])
  }
  console.log("FILLLLES", anexos);

  async function PostFile() {
    const formData = new FormData();
    console.log("RECE", anexos[0]);
    formData.append("anexo", anexos)


    const newFile = await api.add("upload/dono/1/tipo/1/processo/2", formData).then((response) => {

      console.log("FILES", response)

      setAnexos(response.data);

      if (response.status !== 201) {
        NotifyError(response.data?.message)
      }
      if (response.status === 201) {
        Notify(response.data?.message)
      }


    }
    ).catch((erro) =>
      NotifyError("Erro Temporario no servidor!")
    )


  }

  async function buscarTipoDocumento() {
    await api.list("tipodocumentos").then((response) => {
      if (response.status === 200) {
        setAnexos((prev) => response.data)
      }
    });

  }
  async function PostData(data) {

    await PostFile();
    const response = await api
      .add('processos', data).then((response) => {

        if (response.status !== 201) {
          const { data } = response
          console.log("DATA", data);
          NotifyError(response?.data?.message)
        }
        if (response.status === 201) {
          Notify(response?.data?.message)
        }
      }).catch(() => {
        NotifyError("Älgo deu Errado")
      }
      )


  }

  return (
    <AppButtonRoot>
      <Box className="breadcrumb">
        <Breadcrumb
          routeSegments={[
            { name: "Material", path: "/material" },
            { name: "Buttons" },
          ]}
        />
      </Box>
      <SimpleCard title="">
        <H3> REGISTO DE PEDIDO DE VISTO</H3>
      </SimpleCard>
      <Box py="12px" />
      <CForm onSubmit={handleSubmit(PostData)}>
        <SimpleCard item lg={6} md={6} sm={12} xs={12} sx={{ mt: 2 }}>
          <CRow className="mb-4">
            <CCol>
              <CFormInput
                type="text"
                label="Nome Completo"
                aria-label="Antonio Machado"
                aria-describedby="exampleFormControlInputHelpInline"
                text={errors.nome && <div className="text-light bg-danger">{errors.nome.message}</div>}
                {...register('nome')}
              />

            </CCol>
            <CCol >
              <CFormSelect
                id="genero"
                aria-describedby="exampleFormControlInputHelpInline"
                text={errors.generos && <div className="text-light bg-danger">{errors.generos.message}</div>}
                label="Genero"
                required
                {...register("genero")}
              >
                <option disabled>Genero</option>
                {[{ name: "Masculino" }, { name: "Femenino" }].map((estado) =>
                  <option key={estado.name}>{estado.name}</option>
                )}
              </CFormSelect>
            </CCol>
          </CRow>

          <CRow className="mb-4">
            <CCol >
              <CFormInput
                type="text"
                {...register('numDocumentoIdentificacao')}
                label="N documento"
                aria-describedby="exampleFormControlInputHelpInline"
                text={errors.numDocumentoIdentificacao && <div className="text-light bg-danger">{errors.numDocumentoIdentificacao.message}</div>}
              />

            </CCol>
            <CCol>

              <CFormInput
                type="date"
                label="Data de Nascimento"
                aria-label="data"
                aria-describedby="exampleFormControlInputHelpInline"
                text={errors.dataValidadeDocumentoIdentificacao && <div className="text-light bg-danger">{errors.dataValidadeDocumentoIdentificacao.message}</div>}
                {...register('dataValidadeDocumentoIdentificacao')}
              />
            </CCol>
          </CRow>

          <CRow className="mb-4">
            <CCol >
              <CFormSelect
                id="estadoCivil"
                required
                {...register("estadoCivil")}
                label="Estado Civil"
                aria-describedby="exampleFormControlInputHelpInline"
                text={errors.estadoCivil && <div className="text-light bg-danger">{errors.estadoCivil.message}</div>}
                {...register('dataValidadeDocumentoIdentificacao')}

              >
                <option disabled>Selecione</option>
                {[{ name: "Soltero(a)" }, { name: "Casado(a)" }].map((estado) =>
                  <option value={estado.name} key={estado.name}>{estado.name}</option>
                )}
              </CFormSelect>
            </CCol>
            <CCol >
              <CFormSelect
                label="Nacionalidade"
                aria-describedby="exampleFormControlInputHelpInline"
                text={errors?.nacionalidade ? errors.num?.nacionalidade.message : "Bom"}
                required
                {...register("nacionalidade")}

              >
                <option disabled>Nacionalidade</option>
                {listaPais?.map((pais) =>
                  <option value={pais.name} key={pais.name}>{pais.name}</option>
                )}
              </CFormSelect>
              {errors.nacionalidade && <div className="text-light bg-danger">{errors.nacionalidade.message}</div>}
            </CCol>
          </CRow>
          <CRow>
            <CCol className="mb-4">
              <CFormInput
                type="date"
                aria-label="dataNascimento"
                label="Data de Nascimento"
                id="dataNascimento"
                aria-describedby="exampleFormControlInputHelpInline"
                text={errors.dataNascimento && <div className="text-light bg-danger">{errors.dataNascimento.message}</div>}
                {...register('dataNascimento')}
              />
            </CCol>
            <CCol >
              <CFormSelect
                id="paisOrigem"
                label="Pais De Origem"
                aria-describedby="exampleFormControlInputHelpInline"
                text={errors.paisOrigem && <div className="text-light bg-danger">{errors.paisOrigem.message}</div>}
                required
                {...register("paisOrigem")}

              >
                <option disabled>pais</option>
                {listaPais?.map((pais) =>
                  <option value={pais.name} key={pais.name}>{pais.name}</option>
                )}
              </CFormSelect>
            </CCol>
          </CRow>

          <CRow>
            <CCol className="mb-4">
              <CFormInput
                type="text"
                aria-label="codigoPostal"
                id="codigoPostal"
                {...register('codigoPostal')}
                label="Código Postal"
                aria-describedby="exampleFormControlInputHelpInline"
                text={errors.codigoPostal && <div className="text-light bg-danger">{errors.codigoPostal.message}</div>}
              />
            </CCol>
            <CCol className="mb-4">
              <CFormSelect
                id="paisNascimento"
                label="País de Nascimento"
                aria-describedby="exampleFormControlInputHelpInline"
                text={errors.paisNascimento && <div className="text-light bg-danger">{errors.paisNascimento.message}</div>}
                required
                {...register("paisNascimento")}
              >
                <option disabled>selecione</option>
                {listaPais?.map((pais) =>
                  <option value={pais.name} key={pais.name}>{pais.name}</option>
                )}
              </CFormSelect>
            </CCol>
          </CRow>

          <CRow>
            <CCol className="mb-4">
              <CInputGroup className="mb-6 position-relative">
                <CInputGroupText id="n3come"><Phone></Phone></CInputGroupText>

                <CFormInput
                  type="number"
                  aria-label="telefone"
                  placeholder="Telefone"
                  aria-describedby="n3ome"
                  {...register('contacto.telefone')}
                />
              </CInputGroup>
              {errors.contacto?.telefone && <div className="text-light bg-danger">{errors.contacto?.telefone.message}</div>}
            </CCol>
            <CCol className="mb-4">
              <CInputGroup className="mb-6 position-relative">
                <CInputGroupText id="n3come"><Email></Email></CInputGroupText>
                <CFormInput
                  type="email"
                  placeholder="Email"
                  aria-label="email"
                  aria-describedby="n3ome"
                  {...register('contacto.email')}
                />
              </CInputGroup>
              {errors.contacto?.email && <div className="text-light bg-danger">{errors.contacto?.email.message}</div>}
            </CCol>
          </CRow>
        </SimpleCard>
        <Box pt={2}></Box>
        <SimpleCard className="mt-4">
          <H3 className="mb-4"> ENDEREÇO NO PAÍS DE ORIGEM</H3>
          <CRow>

            <CCol className="mb-4">
              <CFormInput
                type="text"
                label="Província/Estado"
                aria-describedby="exampleFormControlInputHelpInline"
                text={errors.enderecoOrigem?.provincia && <div className="text-light bg-danger">{errors.enderecoOrigem?.provincia.message}</div>}
                id="rtr"
                ref={"Aprov"}
                aria-label=" fd"
                {...register('enderecoOrigem.provincia')}
              />
            </CCol>
            <CCol className="mb-4">
              <CFormInput
                type="text"
                ref={"Acity"}
                label="Cidade"
                aria-describedby="exampleFormControlInputHelpInline"
                id="ewe"
                text={errors.enderecoOrigem?.cidade && <div className="text-light bg-danger">{errors.enderecoOrigem?.cidade.message}</div>}
                aria-label="ewe"
                {...register('enderecoOrigem.cidade')}
              />

            </CCol>
          </CRow>
        </SimpleCard>
        <Box pt={2}></Box>
        <SimpleCard className="mt-4">
          <H3 className="mb-4"> ENDEREÇO NO EM ANGOLA</H3>
          <CRow>

            <CCol className="mb-4">

              <CFormInput
                type="text"
                ref={"opro"}
                placeholder="P"
                id="we3"
                aria-label=" fd"
                label="Província/Estado"
                aria-describedby="exampleFormControlInputHelpInline"
                text={errors.enderecoAngola?.provincia && <div className="text-light bg-danger">{errors.enderecoAngola?.provincia.message}</div>}
                {...register('enderecoAngola.provincia')}
              />
            </CCol>
            <CCol className="mb-4">
              <CFormInput
                type="text"
                id="23"
                ref={"ocity"}
                aria-label="fds"
                label="Província/Estado"
                aria-describedby="exampleFormControlInputHelpInline"
                text={errors.enderecoAngola?.cidade && <div className="text-light bg-danger">{errors.enderecoAngola?.cidade?.message}</div>}
                {...register('enderecoAngola.cidade')}
              />
            </CCol>
          </CRow>

        </SimpleCard>


        <Box pt={2}></Box>
        <SimpleCard className="mt-4">
          <H3 className="mb-2"> UPLOD DOS DOCUMENTOS</H3>
          <Paragraph className="mb-4 text-warning">
            Tamanho máximo: 5MB |  Formato : PDF , PNG, TTF, JPEG
          </Paragraph>
          <hr className="mb-8" ></hr>

          {documentos?.map((doc, index) => {
            return (<>
              <CRow>
                <CCol className="mb-4">
                  <span>{doc?.nome}</span>
                  <CInputGroup className="mb-6 position-relative">
                    <CFormInput
                      formEncType="multipart/form-data"
                      text={errors.anexo?.[index] && <div className="text-light bg-danger">{errors.anexo?.[index].message}</div>}
                      aria-describedby="exampleFormControlInputHelpInline"
                      itemRef={index}
                      id={"file" + index}
                      key={doc.nome}
                      accept="image/png, image/jpeg, application/pdf"
                      type="file"
                      required
                      aria-label={doc?.nome}
                      onChange={handleFileChange}
                    />
                  </CInputGroup>
                </CCol>
                {index + 2 && (
                  <CCol className="mb-4">
                    <span>{documentos[index + 1]?.nome}</span>
                    <CInputGroup className="mb-6 position-relative">
                      <CFormInput
                        formEncType="multipart/form-data"
                        text={errors.anexo?.[index + 1] && <div className="text-light bg-danger">{errors.anexo?.[index].message}</div>}
                        aria-describedby="exampleFormControlInputHelpInline"
                        itemRef={index}
                        id={"file" + index + 1}
                        key={documentos[index + 1]?.nome}
                        accept="image/png, image/jpeg, application/pdf"
                        type="file"
                        required
                        aria-label={documentos[index + 1]?.nome}
                        onChange={handleFileChange}
                      />
                    </CInputGroup>
                  </CCol>
                )}

              </CRow>
            </>)
          })}

        </SimpleCard>
        <Box pt={2}></Box>
        <SimpleCard title="">
          <CButton type="submit" className="text-white px-4 w-100" color="success">Salvar</CButton>
        </SimpleCard>
      </CForm>
    </AppButtonRoot >
  );
}
;
const filter = createFilterOptions();
