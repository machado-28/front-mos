import { Box } from "@mui/material";
import { Breadcrumb, SimpleCard } from "app/components";
import React from "react";
import { H1, H3, Paragraph } from "app/components/Typography";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { zodResolver } from "@hookform/resolvers/zod";
import { createFilterOptions } from "@mui/material/Autocomplete";
import { Email, Phone, Title } from "@mui/icons-material";

import {
  CButton,
  CCard,
  CCardBody,
  CCol,
  CContainer,
  CForm,
  CFormInput,
  CFormLabel,
  CFormSelect,
  CHeaderDivider,
  CInputGroup,
  CInputGroupText,
  CNav,
  CNavItem,
  CNavLink,
  CRow,
  CTabContent,
  CTabPane,
} from "@coreui/react";
import { useApi } from "app/hooks/useApi";
import { AppButtonRoot } from "app/components/AppBuutonRoot";
import { useNavigate } from "react-router-dom";
import { functions, values } from "lodash";
import { Bounce, toast } from "react-toastify";
import { listaPais } from "app/utils/paises";
import { Notify, NotifyError } from "app/utils/toastyNotification";
import { useState } from "react";
import FormularioTrabalho from "./Formularios/FormularioTrabalho";
import FormularioTurismo from "./Formularios/FormularioTurismo";
import FormularioCurtaDuracao from "./Formularios/FormularioCurtaDuracao";

export default function SubmterProcesso() {
  const addProcessoShema = z.object({
    nome: z.string().min(1, { message: "Este campo é obrigatorio" }),
    passaporte: z.string(),
    contacto: z.object({
      telefone: z.coerce
        .number({ message: "Telefone Incorrecto" })
        .min(9, { message: "Este campo é obrigatorio" }),
      email: z.string().min(1, { message: "Este campo é obrigatorio!" }),
    }),
    enderecoAngola: z.object({
      provincia: z.string().min(5, { message: "Este campo é obrigatorio" }),
      cidade: z.string().min(5, { message: "Este campo é obrigatorio" }),
    }),
    nacionalidade: z.string().min(5, { message: "Este campo é obrigatorio" }),
    estadoCivil: z.coerce
      .string()
      .min(5, { message: "Este campo é obrigatorio" }),
    genero: z.string().min(5, { message: "Este campo é obrigatorio" }),
    codigoPostal: z.string().min(5, { message: "Este campo é obrigatorio" }),
    dataNascimento: z.coerce.date(),

    enderecoOrigem: z.object({
      provincia: z.string().min(5, { message: "Este campo é obrigatorio" }),
      cidade: z.string().min(5, { message: "Este campo é obrigatorio" }),
    }),
    paisNascimento: z.string().min(2, { message: "Este campo é obrigatorio" }),
  });

  const {
    register,
    reset,
    watch,
    handleSubmit,
    formState: { errors },
  } = useForm({
    resolver: zodResolver(addProcessoShema),
    shouldFocusError: true,
    progressive: true,
  });

  if (errors) console.log("ERRO", errors);
  const api = useApi();
  const [processo, setProcesso] = useState({});
  const [tipoDocumento, setTipoDocumento] = useState({});
  const [anexos, setAnexos] = useState([]);
  const [erroFile, setErroFile] = useState("");
  const redirectTo = useNavigate();
  const [documentos, setDocumentos] = useState([
    { nome: "Bilhete de identidade" },
    { nome: "Passa Porte" },
    { nome: "Curriculumn Profissional" },
  ]);

  const handleFileChange = (event, index) => {
    const fileSize = event.target.files[0].size; // Tamanho do arquivo em bytes
    const maxSize = 2 * 1024 * 1024;
    console.log("SIZE", fileSize, maxSize);
    if (fileSize < maxSize) {
      setErroFile("O tamanho deve ser menor que", maxSize);
      console.log("SIZE", fileSize);
      return;
    }
    setAnexos((prev) => [...prev, event.target.files[0]]);
  };

  console.log("FILLLLES", anexos);

  async function PostFile() {
    const formData = new FormData();
    console.log("RECE", anexos[0]);
    formData.append("anexo", anexos);

    const newFile = await api
      .add("upload/dono/1/tipo/1/processo/2", formData)
      .then((response) => {
        console.log("FILES", response);

        setAnexos(response.data);

        if (response.status !== 201) {
          NotifyError(response.data?.message);
        }
        if (response.status === 201) {
          Notify(response.data?.message);
        }
      })
      .catch((erro) => NotifyError("Erro Temporario no servidor!"));
  }

  async function buscarTipoDocumento() {
    await api.list("tipodocumentos").then((response) => {
      if (response.status === 200) {
        setAnexos((prev) => response.data);
      }
    });
  }
  async function PostData(data) {
    await PostFile();
    const response = await api
      .add("processos", data)
      .then((response) => {
        if (response.status !== 201) {
          const { data } = response;
          console.log("DATA", data);
          NotifyError(response?.data?.message);
        }
        if (response.status === 201) {
          Notify(response?.data?.message);
        }
      })
      .catch(() => {
        NotifyError("Älgo deu Errado");
      });
  }
  const [render, setRender] = useState(0);

  console.log(render);
  return (
    <AppButtonRoot>
      <div className="example">
        <Box className="breadcrumb">
          <Breadcrumb
            routeSegments={[
              { name: "Material", path: "/material" },
              { name: "Buttons" },
            ]}
          />
        </Box>
        <SimpleCard>
          <CNav variant="tabs">
            <CNavItem>
              <CNavLink
                style={{
                  backgroundColor: render === 0 ? "rgb(22, 125, 227)" : "#eee",
                  color: render === 0 ? "#fff " : "#1f1f1f",
                  cursor: "pointer",
                }}
                data="trabalho"
                href="#"
                onClick={() => setRender((prev) => 0)}
                active={render === 0 ? true : false}
              >
                Visto de Trabalho
              </CNavLink>
            </CNavItem>
            <CNavItem>
              <CNavLink
                style={{
                  backgroundColor: render === 1 ? "rgb(22, 125, 227)" : "#eee",
                  color: render === 1 ? "#fff " : "#1f1f1f",
                  cursor: "pointer",
                }}
                data="turismo"
                onClick={() => setRender((prev) => 1)}
                active={render === 1 ? true : false}
              >
                Visto De Turismo
              </CNavLink>
            </CNavItem>
            <CNavItem>
              <CNavLink
                style={{
                  backgroundColor: render === 2 ? "rgb(22, 125, 227)" : "#eee",
                  color: render === 2 ? "#fff " : "#1f1f1f",
                  cursor: "pointer",
                }}
                data="turismo"
                onClick={() => setRender((prev) => 2)}
                active={render === 2 ? true : false}
              >
                Visto De Curta Duração
              </CNavLink>
            </CNavItem>
            <CNavItem>
              <CNavLink
                style={{
                  backgroundColor: render === 3 ? "rgb(22, 125, 227)" : "#eee",
                  color: render === 3 ? "#fff " : "#1f1f1f",
                  cursor: "pointer",
                }}
                data="turismo"
                onClick={() => setRender((prev) => 3)}
                active={render === 3 ? true : false}
              >
                Visto De Fronteira
              </CNavLink>
            </CNavItem>
          </CNav>
        </SimpleCard>

        <CTabContent className="rounded-bottom">
          <CTabPane
            data="trabalho"
            className="preview"
            visible={render === 0 ? true : false}
          >
            <FormularioTrabalho></FormularioTrabalho>
          </CTabPane>
          <CTabPane
            data="turismo"
            className="preview"
            visible={render === 1 ? true : false}
          >
            <FormularioTurismo></FormularioTurismo>
          </CTabPane>

          <CTabPane className="preview" visible={render === 2 ? true : false}>
            <FormularioCurtaDuracao></FormularioCurtaDuracao>
          </CTabPane>
          <CTabPane className="preview" visible={render === 3 ? true : false}>
            <FormularioCurtaDuracao></FormularioCurtaDuracao>
          </CTabPane>
        </CTabContent>
      </div>
    </AppButtonRoot>
  );
}

const filter = createFilterOptions();
