import React, { useEffect, useState } from "react";
import {
  Box,
  Button,
  Checkbox,
  Dialog,
  DialogActions,
  DialogContent,
  DialogContentText,
  DialogTitle,
  FormControlLabel,
  Grid,
  Radio,
  RadioGroup,
  Step,
  StepLabel,
  Stepper,
  TextField as MuiTextField,
  Typography,
} from "@mui/material";
import { styled } from "@mui/material/styles";
import { Breadcrumb, SimpleCard } from "app/components";
import { DatePicker } from "@mui/lab";
import AdapterDateFns from "@mui/lab/AdapterDateFns";
import LocalizationProvider from "@mui/lab/LocalizationProvider";
import { TextValidator, ValidatorForm } from "react-material-ui-form-validator";
import { Link, useParams } from "react-router-dom";
import { H3, H4 } from "app/components/Typography";
import {
  CButton,
  CCol, CForm, CFormInput
  , CFormSelect, CInputGroup, CInputGroupText, CRow
} from "@coreui/react";
import { useApi } from "app/hooks/useApi";
import { Notify, NotifyError } from "app/utils/toastyNotification";

const TextField = styled(TextValidator)(({ theme }) => ({
  width: "100%",
  marginBottom: "16px",
}));

const StyledButton = styled(Button)(({ theme }) => ({
  margin: theme.spacing(1),
}));
export default function DetalharPedido() {
  const [activeStep, setActiveStep] = useState(0);
  const steps = getSteps();
  const [open, setOpen] = useState(false);
  const [state, setState] = useState({ date: new Date() });
  const { id } = useParams()
  const handleClickOpen = () => setOpen(true);
  const handleClose = () => setOpen(false);

  const handleNext = () =>
    setActiveStep((prevActiveStep) => prevActiveStep + 1);
  const handleBack = () =>
    setActiveStep((prevActiveStep) => prevActiveStep - 1);
  const handleReset = () => setActiveStep(0);

  function getSteps() {
    return ["Dados Pessoais", "Informações de Viagem"];
  }
  const api = useApi();
  const [processo, setProcesso] = useState();
  const [listStatus, setListStatus] = useState([]);
  const [statusId, setStatusId] = useState(processo?.status?.nome);
  const { id: processoId } = useParams();

  async function BuscarProcesso() {
    const processosEntrados = await api.list(`processos/${id}`).then((response) => {
      console.log("PRTOCESSO", response.data.processo);
      setProcesso((prev) => response.data.processo)
    })
  }

  useEffect(() => {
    BuscarProcesso()
  }, [])





  async function updateStatus(e) {
    e.preventDefault();

    await api.edit("processos", { processoId, statusId }).then((response) => {
      if (response?.status === 201) {
        Notify(response?.data?.message+"| status:"+response.status)
      }
      if (response?.status !== 201) {
        NotifyError(response?.data?.message+"| status:"+response.status)
      }
    }).catch((error) => {
      console.log(error);
    })
  }

  function handleStatusPedido(event) {
    console.log("SELECT", event.target.value);
    setStatusId((prev) => event.target.value)
  }

  async function buscarStatus(event) {
    const statusencontrados = await api.list("processos/status").then((response) => {
      if (response.status === 200) {
        console.log(response?.data?.status);
        setListStatus((prev) => response?.data?.status)
      }
    }).then((erro) => {
      console.log(erro);
    })
  }

  useEffect(() => {
    buscarStatus()
  }, [])


  return (
    <Box sx={{ margin: "30px" }}>
      <Dialog
        open={open}
        onClose={handleClose}
        aria-labelledby="form-dialog-title"
      >
        <DialogTitle id="form-dialog-title">
          Motivo Da Recusa do Pedio
        </DialogTitle>
        <DialogContent>
          <DialogContentText>
            Descreva aqui a razão da reprovação deste pedido.
          </DialogContentText>
          <MuiTextField
            fullWidth
            autoFocus
            id="motivo"
            type="text"
            margin="dense"
            label="Motivo da recusa"
          />
        </DialogContent>
        <DialogActions>
          <Button variant="outlined" color="secondary" onClick={handleClose}>
            Cancel
          </Button>
          <Button onClick={handleClose} color="primary">
            Enviar
          </Button>
        </DialogActions>
      </Dialog>
      <Box className="breadcrumb">
        <Breadcrumb
          routeSegments={[
            { name: "Material", path: "/material" },
            { name: "Buttons" },
          ]}
        />
      </Box>
      <SimpleCard title="">
        <div>

          <H3>INFORMAÇÕES DO PEDIDO Nº {processo?.id}</H3>
          <Link to={`/processos/${id}/documentos`}>
            <StyledButton variant="contained" color="primary">
              Visualizar  Ficheiros
            </StyledButton>
          </Link>
        </div>
        <hr></hr>
        <CRow>

          {processo?.status?.id === 1 && (<StyledButton
            onClick={handleClickOpen}
            variant="contained"
            color="error"
          >
            Recusar a Solicitção
          </StyledButton>)}
          <CForm onSubmit={updateStatus}>
            <CCol md="auto" >
              <CFormSelect
                id="validationServer04"
                label="Atualizar"
                required
                onChange={handleStatusPedido}

              >
                <option disabled>Actualizar</option>
                <option  >
                  {processo?.status?.nome}
                </option>
                {listStatus?.filter((item) => item.nome !== processo?.status?.nome).map((estado) =>
                  <option key={estado?.nome} value={estado?.id}>{estado?.nome}</option>
                )}
              </CFormSelect>
            </CCol>
            <CCol>
              <CButton type="submit" color="success">Submeter</CButton>
            </CCol>
          </CForm>

        </CRow>
      </SimpleCard>
      <Box py="12px" />
      <Box>
        <Box py="12px" />
        <CForm  >
          <Box pt={4}>
          </Box>
          <SimpleCard item lg={6} md={6} sm={12} xs={12} sx={{ mt: 2 }}>
            <H4 className="m-4" pt={4}>DATA EM QUE FOI {processo?.status?.nome.toLocaleUpperCase()}</H4>
            <CRow className="mb-4">

              <CCol>
                <CInputGroup className="mb-6 position-relative">
                  <CInputGroupText id="nif">
                    Data
                  </CInputGroupText>
                  <CFormInput
                    readOnly
                    type="text"
                    placeholder="nome"
                    value={new Date(processo?.createdAt).toLocaleString()}
                    aria-label="Antonio Machado"
                    aria-describedby="nome"
                  />
                </CInputGroup>
              </CCol>
            </CRow>
          </SimpleCard>
          <SimpleCard item lg={6} md={6} sm={12} xs={12} sx={{ mt: 2 }}>
            <H4 className="m-4" pt={4}>DADOS PESSOAIS</H4>


            <CRow className="mb-4">
              <CCol>
                <CInputGroup className="mb-6 position-relative">
                  <CInputGroupText id="nif">
                    Nome Completo
                  </CInputGroupText>
                  <CFormInput
                    readOnly
                    type="text"
                    placeholder="nome"
                    value={processo?.requerente?.nome}

                    aria-label="Antonio Machado"
                    aria-describedby="nome"
                  />
                </CInputGroup>
              </CCol>
              <CCol>
                <CInputGroup className="mb-6 position-relative">
                  <CInputGroupText id="nif">
                    Nascimento
                  </CInputGroupText>
                  <CFormInput
                    readOnly
                    type="text"
                    placeholder="nome"
                    value={new Date(processo?.requerente?.dataNascimento).toLocaleDateString()}

                    aria-label="Antonio Machado"
                    aria-describedby="nome"
                  />
                </CInputGroup>
              </CCol>
            </CRow>
            <CRow className="mb-4">
              <CCol>
                <CInputGroup className="mb-6 position-relative">
                  <CInputGroupText id="nif">
                    Nº Doc.Identificacao
                  </CInputGroupText>
                  <CFormInput

                    type="text"
                    placeholder="nome"
                    readOnly
                    value={processo?.requerente?.numDocumentoIdentificacao}
                    aria-label="Antonio Machado"
                    aria-describedby="nome"
                  />
                </CInputGroup>
              </CCol>
              <CCol>
                <CInputGroup className="mb-6 position-relative">
                  <CInputGroupText id="nif">
                    Nacionalidade
                  </CInputGroupText>
                  <CFormInput
                    readOnly
                    type="text"
                    placeholder="nome"
                    value={processo?.requerente?.nacionalidade}
                  />
                </CInputGroup>
              </CCol>
            </CRow>

            <CRow className="mb-4">
              <CCol>
                <CInputGroup className="mb-6 position-relative">
                  <CInputGroupText id="nif">
                    País de Nascimento
                  </CInputGroupText>
                  <CFormInput
                    readOnly
                    type="text"
                    placeholder="nome"
                    value={processo?.requerente?.paisNascimento}

                    aria-label="Antonio Machado"
                    aria-describedby="nome"
                  />
                </CInputGroup>
              </CCol>
              <CCol>
                <CInputGroup className="mb-6 position-relative">
                  <CInputGroupText id="nif">
                    Genero
                  </CInputGroupText>
                  <CFormInput
                    readOnly
                    type="text"
                    placeholder="nome"
                    value={processo?.requerente?.genero}
                    aria-label="Antonio Machado"
                    aria-describedby="nome"
                  />
                </CInputGroup>
              </CCol>
            </CRow>
            <CRow className="mb-4">
              <CCol>
                <CInputGroup className="mb-6 position-relative">
                  <CInputGroupText id="nif">
                    Estado Civil
                  </CInputGroupText>
                  <CFormInput
                    readOnly
                    type="text"
                    placeholder="nome"
                    value={processo?.requerente?.estadoCivil}
                    ria-label="Antonio Machado"

                  />
                </CInputGroup>
              </CCol>
              <CCol>
                <CInputGroup className="mb-6 position-relative">
                  <CInputGroupText id="nif">
                    Codigo Postal
                  </CInputGroupText>
                  <CFormInput
                    readOnly
                    type="text"
                    placeholder="nome"
                    value={processo?.requerente?.codigoPostal}

                  />
                </CInputGroup>
              </CCol>
            </CRow>
          </SimpleCard>

          <Box pt={4}>
          </Box>
          <SimpleCard item lg={6} md={6} sm={12} xs={12} sx={{ mt: 2 }}>
            <H4 className="m-4" pt={4}>DADOS ENDEREÇO EM ANGOLA</H4>
            <CRow className="mb-4">
              <CCol>
                <CInputGroup className="mb-6 position-relative">
                  <CInputGroupText id="nif">
                    Provincia
                  </CInputGroupText>
                  <CFormInput
                    readOnly
                    type="text"
                    placeholder="nome"
                    value={processo?.requerente?.endereco[1]?.provincia}
                    aria-label="Antonio Machado"
                    aria-describedby="nome"
                  />
                </CInputGroup>
              </CCol>
              <CCol>
                <CInputGroup className="mb-6 position-relative">
                  <CInputGroupText id="nif">
                    Cidade
                  </CInputGroupText>
                  <CFormInput
                    readOnly
                    type="text"
                    placeholder="nome"
                    value={processo?.requerente?.endereco[1]?.cidade}
                    aria-label="Antonio Machado"
                    aria-describedby="nome"
                  />
                </CInputGroup>
              </CCol>
            </CRow>
          </SimpleCard>

          <Box pt={4}>
          </Box>
          <SimpleCard item lg={6} md={6} sm={12} xs={12} sx={{ mt: 2 }}>
            <H4 className="m-4" pt={4}>DADOS ENDEREÇO NO PAÍS DE ORIGEM</H4>
            <CRow className="mb-4">
              <CCol>
                <CInputGroup className="mb-6 position-relative">
                  <CInputGroupText id="nif">
                    Provincia
                  </CInputGroupText>
                  <CFormInput
                    readOnly
                    type="text"
                    placeholder="nome"
                    value={processo?.requerente?.endereco[0]?.provincia}
                    aria-label="Antonio Machado"
                    aria-describedby="nome"
                  />
                </CInputGroup>
              </CCol>
              <CCol>
                <CInputGroup className="mb-6 position-relative">
                  <CInputGroupText id="nif">
                    Cidade
                  </CInputGroupText>
                  <CFormInput
                    readOnly
                    type="text"
                    placeholder="nome"
                    value={processo?.requerente?.endereco[0]?.cidade}
                    aria-label="Antonio Machado"
                    aria-describedby="nome"
                  />
                </CInputGroup>
              </CCol>
            </CRow>
          </SimpleCard>

          <Box pt={4}>
          </Box>
          <SimpleCard item lg={6} md={6} sm={12} xs={12} sx={{ mt: 2 }}>
            <H4 className="m-4" pt={4}>INFORMAÇÕES DE CONTACTO </H4>
            <CRow className="mb-4">
              <CCol>
                <CInputGroup className="mb-6 position-relative">
                  <CInputGroupText id="nif">
                    Email
                  </CInputGroupText>
                  <CFormInput
                    readOnly
                    type="text"
                    placeholder="nome"
                    value={processo?.requerente?.contacto?.email}
                    aria-label="Antonio Machado"
                    aria-describedby="nome"
                  />
                </CInputGroup>
              </CCol>
              <CCol>
                <CInputGroup className="mb-6 position-relative">
                  <CInputGroupText id="nif">
                    Telefone
                  </CInputGroupText>
                  <CFormInput
                    readOnly
                    type="text"
                    placeholder="nome"
                    value={processo?.requerente?.contacto?.telefone}
                    aria-label="Antonio Machado"
                    aria-describedby="nome"
                  />
                </CInputGroup>
              </CCol>
            </CRow>
          </SimpleCard>
        </CForm>
      </Box>
    </Box>
  );
}
