const { styled, Box } = require("@mui/material");
const { default: PdfViewer } = require("app/components/PdfViewer");
import { Breadcrumb, SimpleCard } from "app/components";
import pdfFile from "./test.pdf";
import { H3 } from "app/components/Typography";
const AppButtonRoot = styled("div")(({ theme }) => ({
  margin: "30px",
  [theme.breakpoints.down("sm")]: { margin: "16px" },
  "& .breadcrumb": {
    marginBottom: "30px",
    [theme.breakpoints.down("sm")]: { marginBottom: "16px" },
  },
  "& .button": { margin: theme.spacing(1) },
  "& .input": { display: "none" },
}));
function getSteps() {
  return [
    "Select master blaster campaign settings",
    "Create an ad group",
    "Create an ad",
  ];
}

export default function DetalharPedido({
  data = [
    {
      url: pdfFile,
      ext: ".pdf",
      tipo: {
        nome: "Bilhte de identidade",
        id: 1,
      },
    },
    {
      url: pdfFile,
      ext: ".pdf",
      tipo: {
        nome: "Passaporte",
        id: 2,
      },
    },
  ],
}) {
  return (
    <frameElement>
      <AppButtonRoot>
        <Box className="breadcrumb">
          <Breadcrumb
            routeSegments={[
              { name: "Material", path: "/material" },
              { name: "Buttons" },
            ]}
          />
        </Box>

        <Box py="12px" />
        <SimpleCard title="">
          <H3> LISTAGEM DE DOCUMENTOS DO PEDIDO {"N-323LA"}</H3>
        </SimpleCard>
        <Box py="12px" />
        {data?.map((documento) => {
          return (
            <>
              {documento?.ext !== ".pdf" ? (
                <SimpleCard title={documento?.tipo?.nome}>
                  <img src={documento?.url}></img>
                </SimpleCard>
              ) : (
                <SimpleCard title={documento?.tipo?.nome}>
                  <PdfViewer fileUrl={documento?.url}></PdfViewer>
                </SimpleCard>
              )}
            </>
          );
        })}
      </AppButtonRoot>
    </frameElement>
  );
}
