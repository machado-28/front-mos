

export default function Detalhar() {
    <>detalhe</>
}