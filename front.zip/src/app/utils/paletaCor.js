export default {
  Turismo: "#FF5733",
  Estudo: "#33FF57",
  Trabalho: "#337AFF",
  Negócios: "#FF33E6",
  Residência: "#33FFEB"
  // Adicione mais tipos de vistos e cores conforme necessário
};
